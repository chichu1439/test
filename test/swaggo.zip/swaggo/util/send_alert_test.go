package util

import (
	"testing"
)

func TestSedAlert(t *testing.T) {
	//alertMsg := fmt.Sprintf("2022Warning!!! This partClearingCode: [%s] transaction failure alarm, msgId: [%s], MsgDefId: [%s], BizSvc: [%s],createDatetime:[%s], evtCd:[%s],evtParam[%s]","001","12345678","admi.004.001.02","ADMISV",time.Now().Format("2006-01-02T15:04:05:006Z"),"BBLT","HBT" + strconv.FormatFloat(16.0, 'f', 10, 32))
	//
	//SedAlert("rsmMonitorAlertMetric",alertMsg,"001"+":Transaction Limit Exceeds The Threshold")
}