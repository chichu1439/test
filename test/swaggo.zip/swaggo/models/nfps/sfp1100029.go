// Package models will define request and response message struct
// Version: v0.0.1
package models

type FP110029I ISO85830220BillPaymentData

type FP110029O ISO85830230BillPaymentData