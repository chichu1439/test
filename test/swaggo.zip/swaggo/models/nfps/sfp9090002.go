package models

type FP909002I struct {
}

type FP909002O struct {
}

func (*FP909002I) GetServiceKey() string {
	return "FP909002"
}
