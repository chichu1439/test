// Package models will define request and response message struct
// Version: v0.0.1
package models

type FP710002I struct {
}

type FP710002O struct {
}
