//Version: v1.0.0
package models

type NT000010I struct {
	StrategyId int `json:"strategyId" validate:"required" description:"Strategy Id"`
}

type NT000010O struct {
}
