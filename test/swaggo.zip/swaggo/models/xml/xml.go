package xml

type Name struct {
	Space, Local string
}
