package models

type IC000046I struct {
}

type IC000046O struct {
}

func (*IC000046I) GetServiceKey() string {
	return "IC000046"
}
