package models

type IC000051I struct {
}

type IC000051O struct {
}

func (*IC000051I) GetServiceKey() string {
	return "IC000051"
}
