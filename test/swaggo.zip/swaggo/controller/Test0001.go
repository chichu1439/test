package controller

// import "github.com/gin-gonic/gin"

// // Topic godoc
// // @Summary     desc
// // @Description desc
// // @Tags        paymentSwitch
// // @Param       TopicRequest body     models.TopicI true "desc"
// // @Success     200                        {object} controller.Response{response=models.TopicO}
// // @Failure     500                {object} controller.Error
// // @Router     urlpath [post]
// func (c *Controller) Topic(ctx *gin.Context) {

// }
